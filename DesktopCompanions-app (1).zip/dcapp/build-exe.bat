@echo off
chcp 65001 >nul
echo === Desktop Companions: build .exe ===
where node >nul 2>nul || (echo ต้องติดตั้ง Node.js ก่อน: https://nodejs.org & pause & exit /b 1)
call npm install || (pause & exit /b 1)
call npm run dist || (pause & exit /b 1)
echo.
echo เสร็จแล้ว! ไฟล์อยู่ในโฟลเดอร์ dist\
explorer dist
pause
