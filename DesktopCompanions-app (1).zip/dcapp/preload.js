const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('dcBridge', {
  setIgnore: v => ipcRenderer.send('dc:ignore', !!v),
  setMode: m => ipcRenderer.send('dc:mode', m),
  dragStart: () => ipcRenderer.send('dc:drag-start'),
  dragEnd: () => ipcRenderer.send('dc:drag-end'),
  onIdle: cb => ipcRenderer.on('dc:idle', (_, v) => cb(!!v)),
  quit: () => ipcRenderer.send('dc:quit'),
});
