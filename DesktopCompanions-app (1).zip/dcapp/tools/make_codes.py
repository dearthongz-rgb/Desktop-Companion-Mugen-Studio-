#!/usr/bin/env python3
"""สร้างโค้ดผู้สนับสนุน / โค้ดเหรียญ สำหรับ Desktop Companions
ใช้:  python3 make_codes.py sup 10        -> โค้ดผู้สนับสนุน 10 โค้ด (ให้ 🪙300)
      python3 make_codes.py coins 5 500   -> โค้ดเหรียญ 5 โค้ด โค้ดละ 500 เหรียญ
ผลลัพธ์: (1) รายการโค้ดไว้ขาย/ส่งให้ลูกค้า (2) บรรทัด JS ที่ต้องนำไปใส่ใน const REDEEM={...} ในไฟล์เกม
เกมเก็บเฉพาะ 'แฮช' ของโค้ด ไม่เก็บตัวโค้ดจริง"""
import sys,hashlib,secrets
A='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
def code():return 'DC-'+''.join(secrets.choice(A) for _ in range(4))+'-'+''.join(secrets.choice(A) for _ in range(4))
def h(c):return hashlib.sha256(('dc-v1|'+c.strip().upper()).encode()).hexdigest()
kind=sys.argv[1] if len(sys.argv)>1 else 'sup';n=int(sys.argv[2]) if len(sys.argv)>2 else 5;amt=int(sys.argv[3]) if len(sys.argv)>3 else 300
cs=[code() for _ in range(n)]
print('# โค้ดสำหรับแจก/ขาย'); [print(c) for c in cs]
print('\n# วางต่อท้ายใน const REDEEM={ ... } (คั่นด้วยจุลภาค)')
for c in cs:print("'%s':{t:'%s',n:%d},"%(h(c),kind,amt))
