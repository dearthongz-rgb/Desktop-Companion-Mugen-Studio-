'use strict';
const { app, BrowserWindow, Tray, Menu, nativeImage, ipcMain, screen, globalShortcut, powerMonitor } = require('electron');
const path = require('path');
const fs = require('fs');

const ICON = path.join(__dirname, 'build', 'icon.png');
const SIZES = { 'เล็ก': 420, 'กลาง': 560, 'ใหญ่': 720, 'ใหญ่มาก': 900 };   // ความกว้างอ้างอิงของ "ฉาก" -> ขนาดตัวน้อง
let cfg = { mode: 'garden', size: 560, oy: 0, hidden: false };
let win = null, tray = null, quitting = false, switching = false;

const cfgFile = () => path.join(app.getPath('userData'), 'settings.json');
function loadCfg() { try { cfg = { ...cfg, ...JSON.parse(fs.readFileSync(cfgFile(), 'utf8')) }; } catch (e) {} }
function saveCfg() { try { fs.writeFileSync(cfgFile(), JSON.stringify(cfg)); } catch (e) {} }

if (!app.requestSingleInstanceLock()) { app.quit(); }
else app.on('second-instance', () => { if (win) { win.show(); if (cfg.mode === 'garden') win.focus(); } });

// หน้าต่าง overlay กว้างเต็มพื้นที่ใช้งานของจอ (ไม่รวมแถบงาน) เพื่อให้น้องเดินได้ทั้งแนวนอน
function sceneH() { return Math.round(cfg.size * 130 / 240); }
function baseY() { const wa = screen.getPrimaryDisplay().workArea, h = sceneH() + 40; return wa.y + wa.height - h + Math.round(sceneH() * 0.065); }
function overlayBounds() {
  const wa = screen.getPrimaryDisplay().workArea, h = sceneH() + 40;
  const maxUp = baseY() - wa.y;
  cfg.oy = Math.max(0, Math.min(cfg.oy || 0, maxUp));
  return { x: wa.x, y: baseY() - cfg.oy, width: wa.width, height: h };
}

function createWindow(mode, go) {
  const common = { icon: ICON, show: false, webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, backgroundThrottling: false } };
  const index = path.join(__dirname, 'renderer', 'index.html');
  if (mode === 'overlay') {
    const b = overlayBounds();
    win = new BrowserWindow({ ...common, ...b, transparent: true, frame: false, hasShadow: false, resizable: false, maximizable: false, minimizable: false, fullscreenable: false, skipTaskbar: true, alwaysOnTop: true, focusable: true, backgroundColor: '#00000000' });
    win.setAlwaysOnTop(true, 'screen-saver');
    win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
    win.setIgnoreMouseEvents(true, { forward: true });
    win.loadFile(index, { query: { mode: 'overlay', ref: String(cfg.size) } });
    win.once('ready-to-show', () => { if (!cfg.hidden) win.showInactive(); });
  } else {
    win = new BrowserWindow({ ...common, width: 860, height: 940, minWidth: 460, minHeight: 600, title: 'Desktop Companions', backgroundColor: '#efe3c8', autoHideMenuBar: true });
    win.setMenuBarVisibility(false);
    win.loadFile(index, go ? { query: { go: '1' } } : undefined);
    win.once('ready-to-show', () => win.show());
  }
  win.on('closed', () => { win = null; if (!switching && !quitting) app.quit(); });
  buildTray();
}

function switchMode(mode) {
  cfg.mode = mode; cfg.hidden = false; saveCfg();
  if (!win) return createWindow(mode, true);
  switching = true;
  const old = win;
  old.removeAllListeners('closed');
  old.webContents.executeJavaScript('window.dispatchEvent(new Event("pagehide"))').catch(() => {}).finally(() => {
    old.once('closed', () => { win = null; switching = false; createWindow(mode, true); });
    old.destroy();
  });
}

function toggleHidden() {
  if (!win || cfg.mode !== 'overlay') return;
  cfg.hidden = !cfg.hidden; saveCfg();
  cfg.hidden ? win.hide() : win.showInactive();
  buildTray();
}

function buildTray() {
  if (!tray) { tray = new Tray(nativeImage.createFromPath(ICON).resize({ width: 32, height: 32 })); tray.setToolTip('Desktop Companions'); tray.on('click', () => { cfg.mode === 'overlay' ? toggleHidden() : win && win.show(); }); }
  const login = app.getLoginItemSettings().openAtLogin;
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'โหมดสวน (เมนู/ร้านค้า/อัลบั้ม)', type: 'radio', checked: cfg.mode === 'garden', click: () => cfg.mode !== 'garden' && switchMode('garden') },
    { label: 'โหมด Overlay บนหน้าจอ', type: 'radio', checked: cfg.mode === 'overlay', click: () => cfg.mode !== 'overlay' && switchMode('overlay') },
    { type: 'separator' },
    { label: cfg.hidden ? 'แสดงน้อง (Ctrl+Alt+P)' : 'ซ่อนน้อง (Ctrl+Alt+P)', enabled: cfg.mode === 'overlay', click: toggleHidden },
    { label: 'ขนาดน้อง', enabled: cfg.mode === 'overlay', submenu: Object.entries(SIZES).map(([n, v]) => ({ label: n, type: 'radio', checked: cfg.size === v, click: () => { cfg.size = v; saveCfg(); if (win && cfg.mode === 'overlay') switchMode('overlay'); } })) },
    { label: 'รีเซ็ตตำแหน่ง (วางบนแถบงาน)', enabled: cfg.mode === 'overlay', click: () => { cfg.oy = 0; saveCfg(); if (win) win.setBounds(overlayBounds()); } },
    { type: 'separator' },
    { label: 'เปิดพร้อม Windows', type: 'checkbox', checked: login, click: m => { app.setLoginItemSettings({ openAtLogin: m.checked, args: [] }); } },
    { label: 'ออกจากโปรแกรม', click: () => { quitting = true; app.quit(); } },
  ]));
}

ipcMain.on('dc:ignore', (e, v) => { if (win && cfg.mode === 'overlay' && e.sender === win.webContents) win.setIgnoreMouseEvents(v, { forward: true }); });
let dragT = null;
ipcMain.on('dc:drag-start', e => {
  if (!win || cfg.mode !== 'overlay') return;
  clearInterval(dragT);
  const y0 = screen.getCursorScreenPoint().y, oy0 = cfg.oy || 0;
  dragT = setInterval(() => {
    if (!win || win.isDestroyed()) return clearInterval(dragT);
    cfg.oy = oy0 + (y0 - screen.getCursorScreenPoint().y);
    win.setBounds(overlayBounds());
  }, 16);
});
ipcMain.on('dc:drag-end', () => { clearInterval(dragT); dragT = null; saveCfg(); });
ipcMain.on('dc:mode', (e, m) => { if (m === 'overlay' || m === 'garden') switchMode(m); });
ipcMain.on('dc:quit', () => { quitting = true; app.quit(); });

app.whenReady().then(() => {
  loadCfg();
  createWindow(cfg.mode, false);
  globalShortcut.register('Control+Alt+P', toggleHidden);
  screen.on('display-metrics-changed', () => { if (win && cfg.mode === 'overlay') win.setBounds(overlayBounds()); });
});
// ผู้ใช้ไม่ได้แตะเครื่อง 3 นาที -> น้องงีบ / กลับมาใช้ -> น้องตื่น
let idleState = false;
setInterval(() => {
  if (!win || win.isDestroyed() || cfg.mode !== 'overlay') return;
  const idle = powerMonitor.getSystemIdleTime() >= 180;
  if (idle !== idleState) { idleState = idle; win.webContents.send('dc:idle', idle); }
}, 5000);
app.on('will-quit', () => globalShortcut.unregisterAll());
app.on('window-all-closed', () => { if (!switching) app.quit(); });
